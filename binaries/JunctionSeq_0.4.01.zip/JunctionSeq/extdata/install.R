#This is a simple script designed to install the JunctionSeq package and all dependencies.
# You can run this script with the command:
# Rscript install.R

