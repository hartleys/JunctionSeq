#!/bin/bash

#Set the correct environment variables, etc.:
source ~/setall.sh

set +o posix

wigToBigWig rawTracks/DAY.fwd.wig.gz rn4.chrom.sizes binaryTracks/DAY.fwd.bw
wigToBigWig rawTracks/DAY.rev.wig.gz rn4.chrom.sizes binaryTracks/DAY.rev.bw
wigToBigWig rawTracks/NIGHT.fwd.wig.gz rn4.chrom.sizes binaryTracks/NIGHT.fwd.bw
wigToBigWig rawTracks/NIGHT.rev.wig.gz rn4.chrom.sizes binaryTracks/NIGHT.rev.bw

wigToBigWig rawTracks/SHAM1.QC.wiggle.fwd.wig.gz rn4.chrom.sizes binaryTracks/SHAM1.QC.wiggle.fwd.bw
wigToBigWig rawTracks/SHAM1.QC.wiggle.rev.wig.gz rn4.chrom.sizes binaryTracks/SHAM1.QC.wiggle.rev.bw

wigToBigWig rawTracks/SHAM1_RG1.QC.wiggle.fwd.wig.gz rn4.chrom.sizes binaryTracks/SHAM1_RG1.QC.wiggle.fwd.bw
wigToBigWig rawTracks/SHAM1_RG1.QC.wiggle.rev.wig.gz rn4.chrom.sizes binaryTracks/SHAM1_RG1.QC.wiggle.rev.bw

zcat rawTracks/testallGenes.coverage.bed.gz | tail -n+2 | sort -k1,1 -k2,2n - > temp.bed
     bedToBigBed temp.bed rn4.chrom.sizes binaryTracks/testallGenes.coverage.bb

zcat rawTracks/testsigGenes.coverage.bed.gz | tail -n+2 | sort -k1,1 -k2,2n - > temp.bed
     bedToBigBed temp.bed rn4.chrom.sizes binaryTracks/testsigGenes.coverage.bb

zcat rawTracks/testsigGenes.pvalues.bed.gz | tail -n+2 | sort -k1,1 -k2,2n - > temp.bed
     bedToBigBed temp.bed  rn4.chrom.sizes binaryTracks/testsigGenes.pvalues.bb

rm temp.bed



 